# Hanabi

OpenSpiel can support Hanabi, using the implementation in
https://github.com/deepmind/hanabi-learning-environment. To enable this option,
see `open_spiel/scripts/global_variables.sh`.
