# Hearts

OpenSpiel can support playing against Nathan Sturtevant's state of the art
Hearts program xinxin (pronounced "sheen-sheen"). To enable this option, see
`open_spiel/scripts/global_variables.sh`.

For more information about xinxin, see its
[github page](https://github.com/nathansttt/hearts) and/or
[Nathan's Hearts research page](https://webdocs.cs.ualberta.ca/~nathanst/hearts.html).
