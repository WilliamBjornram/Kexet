# Authors

Names are ordered lexicographically. Typo or similar contributors are omitted.

## OpenSpiel contributors

-   Bart De Vylder
-   Edward Hughes
-   Edward Lockhart <locked@google.com>
-   Daniel Hennes
-   David Ding
-   Dustin Morrill
-   Elnaz Davoodi
-   Finbarr Timbers
-   Ivo Danihelka
-   Jean-Baptiste Lespiau <jblespiau@google.com>
-   Janos Kramar
-   Jonah Ryan-Davis
-   Julian Schrittwieser
-   Julien Perolat
-   Karl Tuyls
-   Manuel Kroiss
-   Marc Lanctot <lanctot@google.com>
-   Matthew Lai
-   Michal Sustr <michal.sustr@aic.fel.cvut.cz>
-   Raphael Marinier
-   Paul Muller
-   Ryan Faulkner
-   Satyaki Upadhyay
-   Sebastian Borgeaud
-   Sertan Girgin
-   Shayegan Omidshafiei
-   Srinivasan Sriram
-   Thomas Anthony
-   Thomas Köppe
-   Timo Ewalds <tewalds@google.com>
-   Vinicius Zambaldi <vzambaldi@google.com>

## OpenSpiel with Swift for Tensorflow (now removed)

-   James Bradbury <jekbradbury@google.com>
-   Brennan Saeta <saeta@google.com>
-   Dan Zheng <danielzheng@google.com>

## External contributors

See https://github.com/deepmind/open_spiel/graphs/contributors.
